export class Timesheet {
  TimesheetId: number;
  FirstName: string;
  LastName: string;
  Date: Date;
  Hoursworked: number;
}
