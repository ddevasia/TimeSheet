import { Injectable } from '@angular/core';
import { Timesheet } from './timesheet.model'
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class TimesheetService {
  
  timeSheets: Timesheet[];  

  constructor(private http:HttpClient) { }

  addTimeSheet(timeSheet: Timesheet) {
    //debugger;     
   
    return this.http.post<any>(`${environment.apiUrl}`, { timeSheet });
  }

  getTimeSheets() {
    //debugger;    
    return this.http.get<Timesheet[]>(`${environment.apiUrl}/GetAllSheets`);
  }
}
