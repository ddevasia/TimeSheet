import { Component, OnInit } from '@angular/core';
import { TimesheetService } from 'src/app/shared/timesheet.service'
import { FormControl, FormGroup, Validators } from "@angular/forms";
import {Timesheet } from '../shared/timesheet.model'
import { Message } from '@angular/compiler/src/i18n/i18n_ast';

@Component({
  selector: 'app-addtimesheet',
  templateUrl: './addtimesheet.component.html',
  styleUrls: ['./addtimesheet.component.css']
})
export class AddtimesheetComponent implements OnInit {
  form: FormGroup;
  loading = false;
  submitted = false;
  timeSheets: Timesheet[];
  private timeSheet: Timesheet = new Timesheet();
 
  constructor(private service: TimesheetService) { }

  ngOnInit() {
    this.resetform();
  }

  onSubmit() { }

  resetform() {
    this.form = new FormGroup({
      fname: new FormControl("", Validators.required),
      lname: new FormControl("", Validators.required),
      date: new FormControl("", Validators.required),
      hours: new FormControl("", Validators.required)
    });   
  }

  get f() {
    return this.form.controls;
  }

  addTimesheet($event) {
    this.submitted = true;
    if (this.form.status === "VALID") {
      this.timeSheet.FirstName = this.f.fname.value;
      this.timeSheet.LastName = this.f.lname.value;
      this.timeSheet.Date = this.f.date.value;
      this.timeSheet.Hoursworked = this.f.hours.value;
      this.service.addTimeSheet(this.timeSheet).subscribe(res => {
      }, err => {
        console.log(err.message);
      }, () => {
        console.log('completed');
        this.resetform();
      });
      this.service.getTimeSheets();
    }

    
}
}
