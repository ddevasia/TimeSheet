import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from "@angular/forms";

import { TimesheetService } from '../shared/timesheet.service';
import { Timesheet } from '../shared/timesheet.model';

@Component({
  selector: 'app-timesheet-details',
  templateUrl: './timesheet-details.component.html',
  styleUrls: ['./timesheet-details.component.css']
})
export class TimesheetDetailsComponent implements OnInit {

  timeSheets: Timesheet[];

  constructor(private service: TimesheetService) { }

  ngOnInit() {
    this.service.getTimeSheets().subscribe(res => {
    this.timeSheets = res;
    }, err => {
      console.log(err.message);
    }, () => {
      console.log('completed');      
    });
  }

}
