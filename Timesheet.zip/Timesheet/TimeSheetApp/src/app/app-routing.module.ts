import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddtimesheetComponent } from './addtimesheet/addtimesheet.component';
import { TimesheetDetailsComponent } from './timesheet-details/timesheet-details.component';


const routes: Routes = [
  { path: 'list', component: TimesheetDetailsComponent},
  { path: 'addTimeSheet', component: AddtimesheetComponent },
  { path: '', redirectTo: '/list',pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
