import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TimesheetDetailsComponent } from './timesheet-details/timesheet-details.component';
import { AddtimesheetComponent } from './addtimesheet/addtimesheet.component';
import { TimesheetService } from './shared/timesheet.service'

@NgModule({
  declarations: [
    AppComponent,
    TimesheetDetailsComponent,
    AddtimesheetComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [TimesheetService],
  bootstrap: [AppComponent]
})
export class AppModule { }
