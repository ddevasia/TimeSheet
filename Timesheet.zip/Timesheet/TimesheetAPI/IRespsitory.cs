﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TimesheetAPI.Models;

namespace TimesheetAPI
{
    public interface IRespsitory
    {
        TimeSheet AddTimeSheet(TimeSheet timeSheet);

        IEnumerable<TimeSheet> GetAllSheets();
    }
}
