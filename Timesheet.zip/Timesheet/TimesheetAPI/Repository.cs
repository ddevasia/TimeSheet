﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TimesheetAPI.Models;

namespace TimesheetAPI
{
    public class Repository: IRespsitory
    {

        private TimeSheetDbContext _timeSheetContext;


        public Repository(TimeSheetDbContext context)
        {
            _timeSheetContext = context;

        }
        public TimeSheet AddTimeSheet(TimeSheet timesheet)
        {
            try
            {
                _timeSheetContext.TimeSheet.Add(timesheet);
                _timeSheetContext.SaveChanges();

                return timesheet;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public IEnumerable<TimeSheet> GetAllSheets()
        {
            try
            {
                var timesheets = _timeSheetContext.TimeSheet.ToList();
                return timesheets;
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
