﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TimesheetAPI.Models;

namespace TimesheetAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("MyPolicy")]
    public class TimeSheetController:Controller
    {
        private IRespsitory _repo;


        public TimeSheetController(IRespsitory repo)
        {
            _repo = repo;

        }

        // GET api/values
        [HttpGet("GetAllSheets")]
        public ActionResult<IEnumerable<TimeSheet>> GetAllSheets()
        {
            try
            {
                var timesheets = _repo.GetAllSheets();
                return Ok(timesheets.ToList());
            }

            catch (Exception ex)
            {
                throw ex;
            }
              }

        // POST api/values
        [HttpPost]
        public ActionResult<TimeSheet> AddTimeSheet([FromBody] TimeSheet timesheet)
        {
            try
            {
               var newTimeSheet= _repo.AddTimeSheet(timesheet);                

                return newTimeSheet;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            
        }        
       
    }
}
