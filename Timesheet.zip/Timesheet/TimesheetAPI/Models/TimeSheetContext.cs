﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TimesheetAPI.Models
{
    public class TimeSheetDbContext : DbContext
    {

        public TimeSheetDbContext(DbContextOptions options) : base(options)
        {

        }
            public DbSet<TimeSheet> TimeSheet { get; set; }
            
    }
}
 