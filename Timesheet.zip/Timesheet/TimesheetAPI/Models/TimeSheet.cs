﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TimesheetAPI.Models
{
    public class TimeSheet
    {
        [Key]
        public int TimesheetId { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public DateTime Date { get; set; }

        public float Hoursworked { get; set; }

    }
}
